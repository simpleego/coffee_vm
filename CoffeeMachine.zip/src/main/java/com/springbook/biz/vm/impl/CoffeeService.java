package com.springbook.biz.vm.impl;

import com.springbook.biz.vm.CoffeeVO;

public interface CoffeeService {
	
	public void getCoins();
	public CoffeeVO salesCoffee();

}
