package com.springbook.biz.vm;

import java.sql.Date;

public class SalesCoffeeVO {
	Date saleDate;
	char coffeeType;
	int salesQty;
	int salePrice;
}

