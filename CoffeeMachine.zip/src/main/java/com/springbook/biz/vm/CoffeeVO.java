package com.springbook.biz.vm;

public class CoffeeVO {
	
	

}
