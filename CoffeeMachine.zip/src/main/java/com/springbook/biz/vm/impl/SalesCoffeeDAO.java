package com.springbook.biz.vm.impl;

public class SalesCoffeeDAO {

}
