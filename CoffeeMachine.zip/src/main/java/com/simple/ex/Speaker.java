package com.simple.ex;

public interface Speaker {
	
	public void volumeUp(); 	
	public void volumeDown();

}
